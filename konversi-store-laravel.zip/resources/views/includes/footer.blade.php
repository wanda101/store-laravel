<footer>
    <div class="row">
    <div class="col-12 text-center">
        <p class="pt-4 pb-2">2020 Copyright store. All Rights Reserver</p>
    </div>
    </div>
</footer>